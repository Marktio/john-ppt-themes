---
version: "1.0"
name: "Soft Lilac"
description: "Gentle lilac with warm violet accents. Friendly and calm for classroom and wellbeing decks."
ppt:
  background: "F3E8FF"
  textPrimary: "3B0764"
  textSecondary: "6B21A8"
  accent: "9333EA"
  accentLight: "C084FC"
  fontHeading: "Helvetica"
  fontBody: "Helvetica"
  fontMono: "Consolas"
  layoutDefault: "full-text"
  titleVariant: "full-text"
  contentVariant: "split"
  chapterVariant: "gold-rule"
---

## Visual Theme & Atmosphere

Soft lilac ground with deep plum text. Calm, friendly, approachable.

## Colour Palette

- Background: `#F3E8FF`
- Primary text: `#3B0764`
- Secondary text: `#6B21A8`
- Accent: `#9333EA`
- Accent light: `#C084FC`

## Typography

- Headings and body: Helvetica

## When to use

Classroom decks, wellbeing and soft-skills talks, gentle explainers.
